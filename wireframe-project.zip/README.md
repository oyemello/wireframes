# Wireframe Project

Built with **IBM Carbon Design System** + React + Vite.

## Get started

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## Deploy to Vercel
Push to GitHub, then import the repo at [vercel.com](https://vercel.com).
Vercel auto-detects Vite — no config needed.
