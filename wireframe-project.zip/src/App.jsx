// src/App.jsx
import React from 'react';
import { Theme, Grid, Column, Tabs, TabList, Tab, Search, Button, DataTable, Table, TableHead, TableRow, TableHeader, TableBody, TableCell, TableContainer, Pagination } from '@carbon/react';

const defaultHeaders = [
  { key: 'name', header: 'Name' },
  { key: 'status', header: 'Status' },
  { key: 'value', header: 'Value' },
  { key: 'date', header: 'Date' }
];

const defaultRows = [
  { id: '1', name: 'Item 1', status: 'New', value: '$100', date: '2023-01-01' },
  { id: '2', name: 'Item 2', status: 'Pending', value: '$200', date: '2023-01-02' },
  { id: '3', name: 'Item 3', status: 'Active', value: '$300', date: '2023-01-03' },
  { id: '4', name: 'Item 4', status: 'Closed', value: '$400', date: '2023-01-04' }
];

function App() {
  return (
    <Theme theme="g100">
      <Grid style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <Column sm={4} md={8} lg={12} style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
          <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', padding: '16px 0' }}>
            <Tabs selected={0}>
              <TabList aria-label="Tabs" contained>
                {[...Array(6)].map((_, i) => (<Tab key={i}>Tab {i + 1}</Tab>))}
              </TabList>
            </Tabs>
            <Search id="search-1" labelText="Search" placeholder="Search..." size="lg" style={{ flex: 1, margin: '0 16px' }} />
            <Button kind="primary" size="lg">Upload XLSX</Button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'row', flex: 1 }}>
            <Column sm={2} md={4} lg={6} style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
              <TableContainer title="Data Table 1" description="First table description" style={{ flex: 1 }}>
                <DataTable rows={defaultRows} headers={defaultHeaders} isSortable>
                  {({
                    rows, headers, getTableProps, getHeaderProps, getRowProps
                  }) => (
                    <Table {...getTableProps()} style={{ width: '100%' }}>
                      <TableHead>
                        <TableRow>
                          {headers.map(h => <TableHeader {...getHeaderProps({ header: h })} key={h.key}>{h.header}</TableHeader>)}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {rows.map(row => (
                          <TableRow {...getRowProps({ row })} key={row.id}>
                            {row.cells.map(cell => <TableCell key={cell.id}>{cell.value}</TableCell>)}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </DataTable>
              </TableContainer>
              <div style={{ display: 'flex', flexDirection: 'row', padding: '8px 0' }}>
                <Button kind="secondary" size="md" style={{ marginRight: '8px', flex: 1 }}>Append Row</Button>
                <Button kind="danger" size="md" style={{ flex: 1 }}>Remove Row</Button>
              </div>
            </Column>

            <Column sm={2} md={4} lg={6} style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
              <TableContainer title="Data Table 2" description="Second table description" style={{ flex: 1 }}>
                <DataTable rows={defaultRows} headers={defaultHeaders} isSortable>
                  {({
                    rows, headers, getTableProps, getHeaderProps, getRowProps
                  }) => (
                    <Table {...getTableProps()} style={{ width: '100%' }}>
                      <TableHead>
                        <TableRow>
                          {headers.map(h => <TableHeader {...getHeaderProps({ header: h })} key={h.key}>{h.header}</TableHeader>)}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {rows.map(row => (
                          <TableRow {...getRowProps({ row })} key={row.id}>
                            {row.cells.map(cell => <TableCell key={cell.id}>{cell.value}</TableCell>)}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </DataTable>
              </TableContainer>
              <div style={{ display: 'flex', flexDirection: 'row', padding: '8px 0' }}>
                <Button kind="secondary" size="md" style={{ marginRight: '8px', flex: 1 }}>Append Row</Button>
                <Button kind="danger" size="md" style={{ flex: 1 }}>Remove Row</Button>
              </div>
            </Column>
          </div>

          <div style={{ padding: '16px 0' }}>
            <Pagination totalItems={40} pageSize={10} pageSizes={[5, 10, 20]} onChange={() => {}} />
          </div>
        </Column>
      </Grid>
    </Theme>
  );
}

export default App;